b=[[1,2],[3,4],[5,6]] 
for i in b
	for j in i
		puts j
	end
end

