a=3+4
a*=5
b = !true
c=+2+3+3
d=2 ** 3 
e=.3 ** 1 + .9
e/=0.5
f=3 ** 1
g=3 ** 1
h=-2
i=-3.6
j=-.3e12
k=.3/.5
l=~4 * 4
m=5 % 4
n = 5/4
o=5 % 4
p=4 * 9
q = 1 << 3 
r =2 >> 4
s = 3 & 4
t = 5  & 5
u = 3 < 5
v = (3 < 5)
w= 3 < 5
x = 3 == 3
'h' == 'r'
#"itt" == "qe"
nil == nil
nil != nil
true == false
#"ha" == "ha" && 1 < 2 || false && nil == nil
aw = a == c && true
a+=0o45
#a > 5 &&  "la" == "po"
