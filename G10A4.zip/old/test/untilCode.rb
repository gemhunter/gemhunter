a = 1
until a >= 20
	a+=1
	if a<15
		a+=2
		next
	else
                $a = 21
                c = 'h'
		break
	end
        c=0.7
end
a = $a
c = 2
