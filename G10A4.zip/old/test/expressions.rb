-12 && 1 ** ( !a + 123 ) - -123.32 + 12
"ha" + "lk" * 23 >> 2
a = 1.2 + 2
a=2
a[2] += (2+b[2])[1] ;
( 2.3 == !a )
(10+20)
nil
self .. __ENCODING__
(false + true) / __FILE__ >> __LINE__
$0
$kipper
@@oswald
@pingu
_noddy?
BobTheBuilder
2.0
42
[42,20-10,+10,-10,!a]
super
super()[al] **= @@oswald
_adf?(a,10).Cons /= "ha" + "lk" * 23 >> 2
